const RENDER_QUANTUM_FRAMES = 128;
const CHANNELS = 2;
const FLOAT_EPSILON = 1e-10;
function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
function hasSignificantChange(a, b) {
  return Math.abs(a - b) > FLOAT_EPSILON;
}
class FifoSampleBuffer {
  constructor() {
    this._vector = new Float32Array(0);
    this._positionFrames = 0;
    this._frameCount = 0;
  }
  get vector() {
    return this._vector;
  }
  get positionFrames() {
    return this._positionFrames;
  }
  /** Index (en samples) du début des données valides */
  get startIndex() {
    return this._positionFrames * CHANNELS;
  }
  get frameCount() {
    return this._frameCount;
  }
  /** Index (en samples) de fin des données valides (exclu) */
  get endIndex() {
    return (this._positionFrames + this._frameCount) * CHANNELS;
  }
  clear() {
    this.receive(this._frameCount);
    this.rewind();
  }
  /** “Réserve” numFrames frames dans le buffer (après écriture manuelle dans `vector`). */
  put(numFrames) {
    this._frameCount += numFrames;
  }
  /**
   * Ajoute des samples interleaved au buffer.
   *
   * @param samples - samples interleaved
   * @param positionFrames - offset (en frames) dans `samples`
   * @param numFrames - nombre de frames à copier
   */
  putSamples(samples, positionFrames = 0, numFrames = -1) {
    const sourceOffset = positionFrames * CHANNELS;
    const frames = numFrames >= 0 ? numFrames : Math.floor((samples.length - sourceOffset) / CHANNELS);
    const numSamples = frames * CHANNELS;
    this.ensureCapacity(this._frameCount + frames);
    const destOffset = this.endIndex;
    this._vector.set(samples.subarray(sourceOffset, sourceOffset + numSamples), destOffset);
    this._frameCount += frames;
  }
  /**
   * Copie des frames depuis un autre FIFO.
   */
  putBuffer(buffer, positionFrames = 0, numFrames = -1) {
    const frames = numFrames >= 0 ? numFrames : buffer.frameCount - positionFrames;
    this.putSamples(buffer.vector, buffer.positionFrames + positionFrames, frames);
  }
  /**
   * Consomme des frames.
   */
  receive(numFrames = this._frameCount) {
    const frames = clamp(numFrames, 0, this._frameCount);
    this._frameCount -= frames;
    this._positionFrames += frames;
  }
  /**
   * Copie `numFrames` frames dans `output` (interleaved), puis consomme ces frames.
   * Si moins de frames sont disponibles, la partie manquante n'est pas écrite.
   */
  receiveSamples(output, numFrames) {
    const numSamples = numFrames * CHANNELS;
    const sourceOffset = this.startIndex;
    output.set(this._vector.subarray(sourceOffset, sourceOffset + numSamples));
    this.receive(numFrames);
  }
  /**
   * Extrait sans consommer.
   */
  extract(output, positionFrames = 0, numFrames = 0) {
    const sourceOffset = this.startIndex + positionFrames * CHANNELS;
    const numSamples = numFrames * CHANNELS;
    output.set(this._vector.subarray(sourceOffset, sourceOffset + numSamples));
  }
  ensureCapacity(numFrames) {
    const minLength = Math.max(0, Math.ceil(numFrames * CHANNELS));
    if (this._vector.length < minLength) {
      const newVector = new Float32Array(minLength);
      newVector.set(this._vector.subarray(this.startIndex, this.endIndex));
      this._vector = newVector;
      this._positionFrames = 0;
      return;
    }
    this.rewind();
  }
  ensureAdditionalCapacity(numFrames) {
    this.ensureCapacity(this._frameCount + numFrames);
  }
  rewind() {
    if (this._positionFrames === 0)
      return;
    this._vector.copyWithin(0, this.startIndex, this.endIndex);
    this._positionFrames = 0;
  }
}
class AbstractFifoSamplePipe {
  constructor() {
    this.inputBuffer = new FifoSampleBuffer();
    this.outputBuffer = new FifoSampleBuffer();
  }
  clear() {
    this.inputBuffer.clear();
    this.outputBuffer.clear();
  }
}
class RateTransposer extends AbstractFifoSamplePipe {
  constructor() {
    super(...arguments);
    this._rate = 1;
    this.slopeCount = 0;
    this.prevSampleL = 0;
    this.prevSampleR = 0;
  }
  set rate(rate) {
    this._rate = rate;
  }
  reset() {
    this.slopeCount = 0;
    this.prevSampleL = 0;
    this.prevSampleR = 0;
  }
  process() {
    const numFrames = this.inputBuffer.frameCount;
    if (numFrames === 0)
      return;
    this.outputBuffer.ensureAdditionalCapacity(numFrames / this._rate + 1);
    const numFramesOutput = this.transpose(numFrames);
    this.inputBuffer.receive(numFrames);
    this.outputBuffer.put(numFramesOutput);
  }
  transpose(numFrames) {
    if (numFrames === 0)
      return 0;
    const src = this.inputBuffer.vector;
    const srcOffset = this.inputBuffer.startIndex;
    const dest = this.outputBuffer.vector;
    const destOffset = this.outputBuffer.endIndex;
    let used = 0;
    let outFrames = 0;
    while (this.slopeCount < 1) {
      dest[destOffset + CHANNELS * outFrames] = (1 - this.slopeCount) * this.prevSampleL + this.slopeCount * src[srcOffset];
      dest[destOffset + CHANNELS * outFrames + 1] = (1 - this.slopeCount) * this.prevSampleR + this.slopeCount * src[srcOffset + 1];
      outFrames++;
      this.slopeCount += this._rate;
    }
    this.slopeCount -= 1;
    if (numFrames !== 1) {
      outer:
        while (true) {
          while (this.slopeCount > 1) {
            this.slopeCount -= 1;
            used++;
            if (used >= numFrames - 1)
              break outer;
          }
          const srcIndex = srcOffset + CHANNELS * used;
          dest[destOffset + CHANNELS * outFrames] = (1 - this.slopeCount) * src[srcIndex] + this.slopeCount * src[srcIndex + 2];
          dest[destOffset + CHANNELS * outFrames + 1] = (1 - this.slopeCount) * src[srcIndex + 1] + this.slopeCount * src[srcIndex + 3];
          outFrames++;
          this.slopeCount += this._rate;
        }
    }
    this.prevSampleL = src[srcOffset + CHANNELS * numFrames - 2];
    this.prevSampleR = src[srcOffset + CHANNELS * numFrames - 1];
    return outFrames;
  }
}
const DEFAULT_SEQUENCE_MS = 0;
const DEFAULT_SEEKWINDOW_MS = 0;
const DEFAULT_OVERLAP_MS = 8;
const SCAN_OFFSETS = [
  [124, 186, 248, 310, 372, 434, 496, 558, 620, 682, 744, 806, 868, 930, 992, 1054, 1116, 1178, 1240, 1302, 1364, 1426, 1488, 0],
  [-100, -75, -50, -25, 25, 50, 75, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [-20, -15, -10, -5, 5, 10, 15, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [-4, -3, -2, -1, 1, 2, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
];
const AUTOSEQ_TEMPO_LOW = 0.25;
const AUTOSEQ_TEMPO_TOP = 4;
const AUTOSEQ_AT_MIN = 125;
const AUTOSEQ_AT_MAX = 50;
const AUTOSEQ_K = (AUTOSEQ_AT_MAX - AUTOSEQ_AT_MIN) / (AUTOSEQ_TEMPO_TOP - AUTOSEQ_TEMPO_LOW);
const AUTOSEQ_C = AUTOSEQ_AT_MIN - AUTOSEQ_K * AUTOSEQ_TEMPO_LOW;
const AUTOSEEK_AT_MIN = 25;
const AUTOSEEK_AT_MAX = 15;
const AUTOSEEK_K = (AUTOSEEK_AT_MAX - AUTOSEEK_AT_MIN) / (AUTOSEQ_TEMPO_TOP - AUTOSEQ_TEMPO_LOW);
const AUTOSEEK_C = AUTOSEEK_AT_MIN - AUTOSEEK_K * AUTOSEQ_TEMPO_LOW;
class Stretch extends AbstractFifoSamplePipe {
  constructor(sampleRate2) {
    super();
    this.quickSeek = true;
    this.overlapMs = DEFAULT_OVERLAP_MS;
    this.sequenceMs = DEFAULT_SEQUENCE_MS;
    this.seekWindowMs = DEFAULT_SEEKWINDOW_MS;
    this.autoSeqSetting = true;
    this.autoSeekSetting = true;
    this.overlapLength = 0;
    // frames
    this.seekWindowLength = 0;
    // frames
    this.seekLength = 0;
    // frames
    this.nominalSkip = 0;
    this.skipFract = 0;
    this.sampleReq = 0;
    this._tempo = 1;
    this.midBuffer = new Float32Array(0);
    this.refMidBuffer = new Float32Array(0);
    this.midBufferInitialized = false;
    this.sampleRate = sampleRate2;
    this.setParameters(sampleRate2, DEFAULT_SEQUENCE_MS, DEFAULT_SEEKWINDOW_MS, DEFAULT_OVERLAP_MS);
  }
  clear() {
    super.clear();
    this.midBufferInitialized = false;
  }
  set tempo(newTempo) {
    this._tempo = newTempo;
    this.calculateSequenceParameters();
    this.nominalSkip = this._tempo * (this.seekWindowLength - this.overlapLength);
    this.skipFract = 0;
    const intSkip = Math.floor(this.nominalSkip + 0.5);
    this.sampleReq = Math.max(intSkip + this.overlapLength, this.seekWindowLength) + this.seekLength;
  }
  get tempo() {
    return this._tempo;
  }
  setParameters(sampleRate2, sequenceMs, seekWindowMs, overlapMs) {
    if (sampleRate2 > 0)
      this.sampleRate = sampleRate2;
    if (overlapMs > 0)
      this.overlapMs = overlapMs;
    if (sequenceMs > 0) {
      this.sequenceMs = sequenceMs;
      this.autoSeqSetting = false;
    } else {
      this.autoSeqSetting = true;
    }
    if (seekWindowMs > 0) {
      this.seekWindowMs = seekWindowMs;
      this.autoSeekSetting = false;
    } else {
      this.autoSeekSetting = true;
    }
    this.calculateSequenceParameters();
    this.calculateOverlapLength(this.overlapMs);
    this.tempo = this._tempo;
    this.midBufferInitialized = false;
  }
  process() {
    if (!this.midBufferInitialized) {
      if (this.inputBuffer.frameCount < this.overlapLength)
        return;
      this.inputBuffer.receiveSamples(this.midBuffer, this.overlapLength);
      this.midBufferInitialized = true;
    }
    while (this.inputBuffer.frameCount >= this.sampleReq) {
      const offset = this.seekBestOverlapPosition();
      this.outputBuffer.ensureAdditionalCapacity(this.overlapLength);
      this.overlap(offset);
      this.outputBuffer.put(this.overlapLength);
      const nonOverlap = this.seekWindowLength - 2 * this.overlapLength;
      if (nonOverlap > 0) {
        this.outputBuffer.putBuffer(this.inputBuffer, offset + this.overlapLength, nonOverlap);
      }
      const start = this.inputBuffer.startIndex + CHANNELS * (offset + this.seekWindowLength - this.overlapLength);
      this.midBuffer.set(this.inputBuffer.vector.subarray(start, start + CHANNELS * this.overlapLength));
      this.skipFract += this.nominalSkip;
      const overlapSkip = Math.floor(this.skipFract);
      this.skipFract -= overlapSkip;
      this.inputBuffer.receive(overlapSkip);
    }
  }
  calculateOverlapLength(overlapInMs) {
    let newOvl = this.sampleRate * overlapInMs / 1e3;
    newOvl = newOvl < 16 ? 16 : newOvl;
    newOvl -= newOvl % 8;
    this.overlapLength = Math.floor(newOvl);
    this.refMidBuffer = new Float32Array(this.overlapLength * CHANNELS);
    this.midBuffer = new Float32Array(this.overlapLength * CHANNELS);
  }
  calculateSequenceParameters() {
    if (this.autoSeqSetting) {
      const seq = clamp(AUTOSEQ_C + AUTOSEQ_K * this._tempo, AUTOSEQ_AT_MAX, AUTOSEQ_AT_MIN);
      this.sequenceMs = Math.floor(seq + 0.5);
    }
    if (this.autoSeekSetting) {
      const seek = clamp(AUTOSEEK_C + AUTOSEEK_K * this._tempo, AUTOSEEK_AT_MAX, AUTOSEEK_AT_MIN);
      this.seekWindowMs = Math.floor(seek + 0.5);
    }
    this.seekWindowLength = Math.floor(this.sampleRate * this.sequenceMs / 1e3);
    this.seekLength = Math.floor(this.sampleRate * this.seekWindowMs / 1e3);
  }
  seekBestOverlapPosition() {
    return this.quickSeek ? this.seekBestOverlapPositionStereoQuick() : this.seekBestOverlapPositionStereo();
  }
  seekBestOverlapPositionStereo() {
    this.preCalculateCorrelationReferenceStereo();
    let bestOffset = 0;
    let bestCorrelation = -Infinity;
    for (let offset = 0; offset < this.seekLength; offset++) {
      const correlation = this.calculateCrossCorrelationStereo(offset, this.refMidBuffer);
      if (correlation > bestCorrelation) {
        bestCorrelation = correlation;
        bestOffset = offset;
      }
    }
    return bestOffset;
  }
  seekBestOverlapPositionStereoQuick() {
    this.preCalculateCorrelationReferenceStereo();
    let bestOffset = 0;
    let bestCorrelation = -Infinity;
    let correlationOffset = 0;
    for (let scanPass = 0; scanPass < 4; scanPass++) {
      const offsets = SCAN_OFFSETS[scanPass];
      for (let j = 0; offsets[j] !== 0; j++) {
        const tempOffset = correlationOffset + offsets[j];
        if (tempOffset >= this.seekLength)
          break;
        const correlation = this.calculateCrossCorrelationStereo(tempOffset, this.refMidBuffer);
        if (correlation > bestCorrelation) {
          bestCorrelation = correlation;
          bestOffset = tempOffset;
        }
      }
      correlationOffset = bestOffset;
    }
    return bestOffset;
  }
  /**
   * Prépare le buffer de référence pour corrélation (pondération).
   */
  preCalculateCorrelationReferenceStereo() {
    for (let i = 0; i < this.overlapLength; i++) {
      const weight = i * (this.overlapLength - i);
      const idx = CHANNELS * i;
      this.refMidBuffer[idx] = this.midBuffer[idx] * weight;
      this.refMidBuffer[idx + 1] = this.midBuffer[idx + 1] * weight;
    }
  }
  /**
   * Corrélation croisée stéréo entre `midBuffer` (référence) et l'entrée
   * à partir de `offsetFrames`.
   */
  calculateCrossCorrelationStereo(offsetFrames, compare) {
    const mixing = this.inputBuffer.vector;
    const mixingPosition = this.inputBuffer.startIndex + CHANNELS * offsetFrames;
    let correlation = 0;
    const calcLengthSamples = CHANNELS * this.overlapLength;
    for (let i = 2; i < calcLengthSamples; i += CHANNELS) {
      const mixIdx = mixingPosition + i;
      correlation += mixing[mixIdx] * compare[i] + mixing[mixIdx + 1] * compare[i + 1];
    }
    return correlation;
  }
  /**
   * Overlap-add de `overlapLength` frames à partir de `offsetFrames`.
   */
  overlap(offsetFrames) {
    const input = this.inputBuffer.vector;
    const inputPosition = this.inputBuffer.startIndex + CHANNELS * offsetFrames;
    const output = this.outputBuffer.vector;
    const outputPosition = this.outputBuffer.endIndex;
    const frameScale = 1 / this.overlapLength;
    for (let i = 0; i < this.overlapLength; i++) {
      const fadeOut = (this.overlapLength - i) * frameScale;
      const fadeIn = i * frameScale;
      const ctx = CHANNELS * i;
      const inIdx = inputPosition + ctx;
      const outIdx = outputPosition + ctx;
      output[outIdx] = input[inIdx] * fadeIn + this.midBuffer[ctx] * fadeOut;
      output[outIdx + 1] = input[inIdx + 1] * fadeIn + this.midBuffer[ctx + 1] * fadeOut;
    }
  }
}
class SoundTouch {
  constructor(sampleRate2) {
    this.inputBuffer = new FifoSampleBuffer();
    this.outputBuffer = new FifoSampleBuffer();
    this.intermediateBuffer = new FifoSampleBuffer();
    this.transposer = new RateTransposer();
    this._rate = 1;
    this._tempo = 1;
    this.virtualPitch = 1;
    this.virtualRate = 1;
    this.virtualTempo = 1;
    this.stretch = new Stretch(sampleRate2);
    this.calculateEffectiveRateAndTempo();
  }
  clear() {
    this.transposer.clear();
    this.stretch.clear();
    this.inputBuffer.clear();
    this.intermediateBuffer.clear();
    this.outputBuffer.clear();
  }
  set rate(rate) {
    this.virtualRate = rate;
    this.calculateEffectiveRateAndTempo();
  }
  get rate() {
    return this._rate;
  }
  set tempo(tempo) {
    this.virtualTempo = tempo;
    this.calculateEffectiveRateAndTempo();
  }
  get tempo() {
    return this._tempo;
  }
  /**
   * `pitch` ici est un ratio (1.0 = pas de changement).
   * Pour des demi-tons, utiliser `2^(semitones/12)`.
   */
  set pitch(pitch) {
    this.virtualPitch = pitch;
    this.calculateEffectiveRateAndTempo();
  }
  process() {
    if (this._rate > 1) {
      this.stretch.process();
      this.transposer.process();
    } else {
      this.transposer.process();
      this.stretch.process();
    }
  }
  calculateEffectiveRateAndTempo() {
    const previousTempo = this._tempo;
    const previousRate = this._rate;
    this._tempo = this.virtualTempo / this.virtualPitch;
    this._rate = this.virtualRate * this.virtualPitch;
    if (hasSignificantChange(this._tempo, previousTempo)) {
      this.stretch.tempo = this._tempo;
    }
    if (hasSignificantChange(this._rate, previousRate)) {
      this.transposer.rate = this._rate;
    }
    if (this._rate > 1) {
      if (this.transposer.outputBuffer !== this.outputBuffer) {
        this.stretch.inputBuffer = this.inputBuffer;
        this.stretch.outputBuffer = this.intermediateBuffer;
        this.transposer.inputBuffer = this.intermediateBuffer;
        this.transposer.outputBuffer = this.outputBuffer;
      }
    } else {
      if (this.stretch.outputBuffer !== this.outputBuffer) {
        this.transposer.inputBuffer = this.inputBuffer;
        this.transposer.outputBuffer = this.intermediateBuffer;
        this.stretch.inputBuffer = this.intermediateBuffer;
        this.stretch.outputBuffer = this.outputBuffer;
      }
    }
  }
}
function paramValue(params, name, fallback) {
  const arr = params[name];
  return arr && arr.length > 0 ? arr[0] : fallback;
}
class SoundTouchProcessor extends AudioWorkletProcessor {
  constructor() {
    super(...arguments);
    this.pipe = new SoundTouch(sampleRate);
    this.inputInterleaved = new Float32Array(RENDER_QUANTUM_FRAMES * CHANNELS);
    this.outputInterleaved = new Float32Array(RENDER_QUANTUM_FRAMES * CHANNELS);
  }
  process(inputs, outputs, parameters) {
    const input = inputs[0];
    const output = outputs[0];
    if (!output || output.length === 0)
      return false;
    const leftOut = output[0];
    const rightOut = output[1] ?? output[0];
    if (!input || input.length === 0 || !input[0]) {
      leftOut.fill(0);
      if (rightOut !== leftOut)
        rightOut.fill(0);
      return true;
    }
    const leftIn = input[0];
    const rightIn = input[1] ?? input[0];
    const rate = paramValue(parameters, "rate", 1);
    const tempo = paramValue(parameters, "tempo", 1);
    const pitch = paramValue(parameters, "pitch", 1);
    const pitchSemitones = paramValue(parameters, "pitchSemitones", 0);
    this.pipe.rate = rate;
    this.pipe.tempo = tempo;
    this.pipe.pitch = pitch * Math.pow(2, pitchSemitones / 12);
    for (let i = 0; i < leftIn.length; i++) {
      this.inputInterleaved[i * 2] = leftIn[i];
      this.inputInterleaved[i * 2 + 1] = rightIn[i];
    }
    this.pipe.inputBuffer.putSamples(this.inputInterleaved, 0, leftIn.length);
    this.pipe.process();
    this.outputInterleaved.fill(0);
    this.pipe.outputBuffer.receiveSamples(this.outputInterleaved, leftOut.length);
    for (let i = 0; i < leftOut.length; i++) {
      const l = this.outputInterleaved[i * 2];
      const r = this.outputInterleaved[i * 2 + 1];
      leftOut[i] = Number.isFinite(l) ? l : 0;
      rightOut[i] = Number.isFinite(r) ? r : 0;
    }
    return true;
  }
  static get parameterDescriptors() {
    return [
      { name: "rate", defaultValue: 1, minValue: 0.25, maxValue: 4 },
      { name: "tempo", defaultValue: 1, minValue: 0.25, maxValue: 4 },
      { name: "pitch", defaultValue: 1, minValue: 0.25, maxValue: 4 },
      { name: "pitchSemitones", defaultValue: 0, minValue: -24, maxValue: 24 }
    ];
  }
}
registerProcessor("soundtouch-processor", SoundTouchProcessor);
//# sourceMappingURL=processor.js.map

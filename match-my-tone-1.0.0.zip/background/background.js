const DEFAULT_PARAMS = {
  hz: 440,
  // Fréquence de base (A4)
  semitons: 0,
  // Décalage en demi-tons
  isEnabled: false
  // État activé/désactivé
};
function calculatePitchSemitones(semitons, hz) {
  const BASE_HZ = 440;
  const hzInSemitones = 12 * Math.log2(hz / BASE_HZ);
  return semitons + hzInSemitones;
}
const HOST_ENABLED_PREFIX = "hostEnabled:";
function storageKeyForHost(host) {
  return `${HOST_ENABLED_PREFIX}${host}`;
}
function tryParseHostname(url) {
  if (!url)
    return null;
  try {
    const u = new URL(url);
    return u.hostname || null;
  } catch {
    return null;
  }
}
class PitchShifterBackground {
  constructor() {
    /**
     * Stockage des paramètres par ID d'onglet (Map = O(1))
     */
    this.tabParams = /* @__PURE__ */ new Map();
    /**
     * Cache (volatile) tabId -> hostname, utile quand le popup envoie seulement tabId.
     * Note: le background MV2 est non-persistant, donc ce cache peut disparaître.
     */
    this.tabHost = /* @__PURE__ */ new Map();
  }
  start() {
    this.installMessageListener();
    this.installTabCleanup();
  }
  // ------------------------------------------------------------
  // Stockage par onglet
  // ------------------------------------------------------------
  async getOrInitTabParams(tabId, host) {
    let params = this.tabParams.get(tabId);
    if (!params) {
      params = { ...DEFAULT_PARAMS };
      if (host) {
        const stored = await this.getStoredEnabledForHost(host);
        if (typeof stored === "boolean") {
          params.isEnabled = stored;
        }
      }
      this.tabParams.set(tabId, params);
    }
    return params;
  }
  async getStoredEnabledForHost(host) {
    const key = storageKeyForHost(host);
    const result = await browser.storage.local.get(key);
    const value = result[key];
    return typeof value === "boolean" ? value : null;
  }
  async setStoredEnabledForHost(host, enabled) {
    const key = storageKeyForHost(host);
    await browser.storage.local.set({ [key]: enabled });
  }
  updateTabParams(tabId, patch) {
    let params = this.tabParams.get(tabId);
    if (!params) {
      params = { ...DEFAULT_PARAMS };
      this.tabParams.set(tabId, params);
    }
    Object.assign(params, patch);
    const msg = {
      type: "paramsUpdate",
      params: {
        pitch: calculatePitchSemitones(params.semitons, params.hz),
        isEnabled: params.isEnabled
      }
    };
    browser.tabs.sendMessage(tabId, msg).catch(() => void 0);
  }
  // ------------------------------------------------------------
  // Messages
  // ------------------------------------------------------------
  installMessageListener() {
    browser.runtime.onMessage.addListener((message, sender) => {
      const msg = this.asIncomingMessage(message);
      if (!msg)
        return;
      if (msg.type === "getParams") {
        const tabId = sender.tab?.id;
        if (typeof tabId === "number") {
          const host = tryParseHostname(sender.url);
          if (host)
            this.tabHost.set(tabId, host);
          return this.getOrInitTabParams(tabId, host ?? this.tabHost.get(tabId) ?? null);
        }
        return Promise.resolve(DEFAULT_PARAMS);
      }
      if (msg.type === "updateParams") {
        if (typeof msg.tabId === "number") {
          const host = typeof msg.host === "string" && msg.host.length > 0 ? msg.host : this.tabHost.get(msg.tabId) ?? null;
          if (host) {
            this.tabHost.set(msg.tabId, host);
            void this.setStoredEnabledForHost(host, msg.params.isEnabled);
          }
          this.updateTabParams(msg.tabId, msg.params);
          return Promise.resolve({ success: true });
        }
        return Promise.resolve({ success: false, error: "No tab ID" });
      }
      if (msg.type === "getCurrentTabParams") {
        return browser.tabs.query({ active: true, currentWindow: true }).then(async (tabs) => {
          const tabId = tabs[0]?.id;
          if (typeof tabId !== "number")
            return DEFAULT_PARAMS;
          const host = tryParseHostname(tabs[0]?.url);
          if (host)
            this.tabHost.set(tabId, host);
          return await this.getOrInitTabParams(tabId, host ?? this.tabHost.get(tabId) ?? null);
        });
      }
    });
  }
  asIncomingMessage(message) {
    if (!message || typeof message !== "object")
      return null;
    const m = message;
    if (m.type === "getParams")
      return { type: "getParams" };
    if (m.type === "getCurrentTabParams")
      return { type: "getCurrentTabParams" };
    if (m.type === "updateParams") {
      const u = message;
      if (typeof u.tabId !== "number")
        return null;
      if (!u.params || typeof u.params !== "object")
        return null;
      const p = u.params;
      if (typeof p.hz !== "number" || typeof p.semitons !== "number" || typeof p.isEnabled !== "boolean") {
        return null;
      }
      return {
        type: "updateParams",
        tabId: u.tabId,
        host: typeof u.host === "string" || u.host === null ? u.host : void 0,
        params: { hz: p.hz, semitons: p.semitons, isEnabled: p.isEnabled }
      };
    }
    return null;
  }
  // ------------------------------------------------------------
  // Nettoyage (évite fuite mémoire)
  // ------------------------------------------------------------
  installTabCleanup() {
    browser.tabs.onRemoved.addListener((tabId) => {
      this.tabParams.delete(tabId);
      this.tabHost.delete(tabId);
    });
  }
}
new PitchShifterBackground().start();
//# sourceMappingURL=background.js.map

const AUDIO_CONFIG = {
  workletName: "soundtouch-processor",
  workletPath: "audio/processor.js",
  fadeTimeSeconds: 0.15,
  // Temps de fade pour éviter les "clicks"
  baseHz: 440
  // Fréquence de base (La4)
};
class PitchShifterContentScript {
  constructor(config) {
    this.config = config;
    this.params = null;
    this.audioContext = null;
    this.workletLoaded = null;
    /**
     * Map des éléments média traités (WeakMap = pas de fuite mémoire)
     */
    this.processed = /* @__PURE__ */ new WeakMap();
  }
  /**
   * Point d’entrée : charge les paramètres, installe les listeners, et observe le DOM.
   */
  async start() {
    console.log("Match My Tone: content script charg\xE9.");
    this.installMessageListener();
    await this.loadInitialParams();
    this.setupExistingElements();
    this.observeDomForNewMedia();
  }
  // ------------------------------------------------------------
  // Messages (background -> content)
  // ------------------------------------------------------------
  installMessageListener() {
    browser.runtime.onMessage.addListener((message) => {
      if (!this.isParamsUpdateMessage(message))
        return;
      this.applyParamsToAll(message.params);
    });
  }
  isParamsUpdateMessage(message) {
    if (!message || typeof message !== "object")
      return false;
    const m = message;
    if (m.type !== "paramsUpdate")
      return false;
    if (!m.params || typeof m.params !== "object")
      return false;
    const p = m.params;
    return typeof p.pitch === "number" && typeof p.isEnabled === "boolean";
  }
  async loadInitialParams() {
    try {
      const raw = await browser.runtime.sendMessage({
        type: "getParams"
      });
      this.params = this.toGlobalAudioParams(raw);
      console.log("Match My Tone: Param\xE8tres initiaux charg\xE9s", this.params);
    } catch (err) {
      console.error("Match My Tone: Impossible d'obtenir les param\xE8tres initiaux.", err);
      this.params = { pitch: 0, isEnabled: false };
    }
  }
  toGlobalAudioParams(raw) {
    const hzInSemitones = 12 * Math.log2(raw.hz / this.config.baseHz);
    return {
      pitch: raw.semitons + hzInSemitones,
      isEnabled: raw.isEnabled
    };
  }
  // ------------------------------------------------------------
  // AudioContext + Worklet
  // ------------------------------------------------------------
  getAudioContextCtor() {
    const w = window;
    const ctor = window.AudioContext ?? w.webkitAudioContext;
    if (!ctor) {
      throw new Error("AudioContext non support\xE9 par ce navigateur.");
    }
    return ctor;
  }
  async ensureAudioContextReady() {
    if (!this.audioContext) {
      console.log("Match My Tone: Initialisation AudioContext...");
      const Ctor = this.getAudioContextCtor();
      this.audioContext = new Ctor();
    }
    if (this.audioContext.state === "suspended") {
      try {
        await this.audioContext.resume();
      } catch {
      }
    }
    if (!this.workletLoaded) {
      const url = browser.runtime.getURL(this.config.workletPath);
      this.workletLoaded = this.audioContext.audioWorklet.addModule(url);
    }
    await this.workletLoaded;
    return this.audioContext;
  }
  // ------------------------------------------------------------
  // Connexion des éléments media
  // ------------------------------------------------------------
  setupExistingElements() {
    document.querySelectorAll("audio, video").forEach((el) => this.setupElement(el));
  }
  setupElement(element) {
    element.addEventListener(
      "play",
      () => {
        void this.connectElement(element);
      },
      { once: true }
    );
    if (!element.paused) {
      void this.connectElement(element);
    }
  }
  async connectElement(element) {
    if (!this.params)
      return;
    if (this.processed.has(element))
      return;
    try {
      const ctx = await this.ensureAudioContextReady();
      const source = ctx.createMediaElementSource(element);
      const workletNode = new AudioWorkletNode(ctx, this.config.workletName);
      const bypassGain = ctx.createGain();
      const effectGain = ctx.createGain();
      const now = ctx.currentTime;
      workletNode.parameters.get("pitchSemitones")?.setValueAtTime(this.params.pitch, now);
      workletNode.parameters.get("tempo")?.setValueAtTime(1, now);
      source.connect(bypassGain).connect(ctx.destination);
      source.connect(workletNode).connect(effectGain).connect(ctx.destination);
      this.setMixImmediate(bypassGain, effectGain, this.params.isEnabled, now);
      this.processed.set(element, { source, workletNode, bypassGain, effectGain });
      console.log(
        `Match My Tone: \xE9l\xE9ment connect\xE9 (${this.params.isEnabled ? "ACTIV\xC9" : "D\xC9SACTIV\xC9"})`,
        element
      );
    } catch (err) {
      console.warn("Match My Tone: impossible de connecter l'\xE9l\xE9ment m\xE9dia.", err);
    }
  }
  setMixImmediate(bypass, effect, enabled, now) {
    if (enabled) {
      bypass.gain.setValueAtTime(0, now);
      effect.gain.setValueAtTime(1, now);
    } else {
      bypass.gain.setValueAtTime(1, now);
      effect.gain.setValueAtTime(0, now);
    }
  }
  // ------------------------------------------------------------
  // Mises à jour de paramètres (pitch + crossfade)
  // ------------------------------------------------------------
  applyParamsToAll(params) {
    const previous = this.params;
    this.params = params;
    if (!this.audioContext)
      return;
    const now = this.audioContext.currentTime;
    const stateChanged = !!previous && previous.isEnabled !== params.isEnabled;
    document.querySelectorAll("audio, video").forEach((element) => {
      const data = this.processed.get(element);
      if (!data)
        return;
      data.workletNode.parameters.get("pitchSemitones")?.linearRampToValueAtTime(params.pitch, now + this.config.fadeTimeSeconds);
      if (stateChanged) {
        this.crossfade(data, params.isEnabled, now);
      }
    });
  }
  cancelAndHold(param, now) {
    param.cancelScheduledValues(now);
    param.setValueAtTime(param.value, now);
  }
  crossfade(data, enabled, now) {
    this.cancelAndHold(data.bypassGain.gain, now);
    this.cancelAndHold(data.effectGain.gain, now);
    const end = now + this.config.fadeTimeSeconds;
    if (enabled) {
      data.bypassGain.gain.linearRampToValueAtTime(0, end);
      data.effectGain.gain.linearRampToValueAtTime(1, end);
    } else {
      data.bypassGain.gain.linearRampToValueAtTime(1, end);
      data.effectGain.gain.linearRampToValueAtTime(0, end);
    }
  }
  // ------------------------------------------------------------
  // DOM observer (YouTube, SPA, etc.)
  // ------------------------------------------------------------
  observeDomForNewMedia() {
    const root = document.body ?? document.documentElement;
    if (!root)
      return;
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          this.trySetupFromNode(node);
        }
      }
    });
    observer.observe(root, { childList: true, subtree: true });
  }
  trySetupFromNode(node) {
    if (node.nodeType !== Node.ELEMENT_NODE)
      return;
    const el = node;
    if (el instanceof HTMLAudioElement || el instanceof HTMLVideoElement) {
      this.setupElement(el);
    }
    el.querySelectorAll?.("audio, video").forEach((child) => {
      this.setupElement(child);
    });
  }
}
if (!window.__pitchShifterAttached) {
  window.__pitchShifterAttached = true;
  console.log("Match My Tone: Script de contenu inject\xE9.");
  void new PitchShifterContentScript(AUDIO_CONFIG).start();
}
//# sourceMappingURL=content-script.js.map

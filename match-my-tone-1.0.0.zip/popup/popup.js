function mustGetElement(id) {
  const el = document.getElementById(id);
  if (!el) {
    throw new Error(`Popup: \xE9l\xE9ment #${id} introuvable`);
  }
  return el;
}
function isRawAudioParams(value) {
  if (!value || typeof value !== "object")
    return false;
  const v = value;
  return typeof v.hz === "number" && typeof v.semitons === "number" && typeof v.isEnabled === "boolean";
}
function tryGetHostname(url) {
  if (!url)
    return null;
  try {
    const u = new URL(url);
    return u.hostname || null;
  } catch {
    return null;
  }
}
class PitchShifterPopup {
  constructor() {
    this.tabId = null;
    this.host = null;
    this.dom = {
      enabled: mustGetElement("enabled"),
      semitones: mustGetElement("semitones"),
      semitonesValue: mustGetElement("semitonesValue"),
      hz: mustGetElement("hz"),
      hzValue: mustGetElement("hzValue")
    };
  }
  start() {
    this.localizeStaticText();
    this.installEventListeners();
    void this.refreshFromBackground();
  }
  /**
   * Applique les traductions sur les éléments statiques du popup.
   * On se base sur des attributs `data-i18n="messageKey"` dans `static/popup.html`.
   */
  localizeStaticText() {
    const elements = document.querySelectorAll("[data-i18n]");
    for (const el of elements) {
      const key = el.dataset.i18n;
      if (!key)
        continue;
      const msg = browser.i18n.getMessage(key);
      if (msg)
        el.textContent = msg;
    }
    const title = browser.i18n.getMessage("popupTitle");
    if (title)
      document.title = title;
  }
  // ------------------------------------------------------------
  // Initialisation / lecture-écriture UI
  // ------------------------------------------------------------
  installEventListeners() {
    this.dom.enabled.addEventListener("change", () => {
      void this.pushUiParams();
    });
    this.dom.semitones.addEventListener("input", () => {
      const value = parseFloat(this.dom.semitones.value);
      this.dom.semitonesValue.textContent = value.toFixed(1);
      void this.pushUiParams();
    });
    this.dom.hz.addEventListener("input", () => {
      this.dom.hzValue.textContent = this.dom.hz.value;
      void this.pushUiParams();
    });
  }
  readUiParams() {
    return {
      isEnabled: this.dom.enabled.checked,
      semitons: parseFloat(this.dom.semitones.value),
      hz: parseFloat(this.dom.hz.value)
    };
  }
  render(params) {
    this.dom.enabled.checked = params.isEnabled;
    this.dom.semitones.value = params.semitons.toString();
    this.dom.semitonesValue.textContent = params.semitons.toFixed(1);
    this.dom.hz.value = params.hz.toString();
    this.dom.hzValue.textContent = params.hz.toString();
  }
  // ------------------------------------------------------------
  // Communication background
  // ------------------------------------------------------------
  async resolveActiveTabId() {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const id = tabs[0]?.id;
    return typeof id === "number" ? id : null;
  }
  async resolveActiveTabHost() {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    return tryGetHostname(tab?.url);
  }
  async refreshFromBackground() {
    try {
      this.tabId = await this.resolveActiveTabId();
      this.host = await this.resolveActiveTabHost();
      if (this.tabId === null) {
        console.warn("Popup: aucun onglet actif d\xE9tect\xE9.");
        return;
      }
      const params = await browser.runtime.sendMessage({ type: "getCurrentTabParams" });
      if (!isRawAudioParams(params)) {
        throw new Error("Popup: r\xE9ponse getCurrentTabParams invalide");
      }
      this.render(params);
    } catch (err) {
      console.error("Popup: erreur lors du chargement des param\xE8tres.", err);
    }
  }
  /**
   * Envoie les paramètres UI au background pour l'onglet actif.
   */
  async pushUiParams() {
    try {
      if (this.tabId === null) {
        this.tabId = await this.resolveActiveTabId();
      }
      if (this.host === null) {
        this.host = await this.resolveActiveTabHost();
      }
      if (this.tabId === null)
        return;
      await browser.runtime.sendMessage({
        type: "updateParams",
        tabId: this.tabId,
        host: this.host,
        params: this.readUiParams()
      });
    } catch (err) {
      console.error("Popup: erreur lors de la mise \xE0 jour des param\xE8tres.", err);
    }
  }
}
document.addEventListener("DOMContentLoaded", () => {
  try {
    new PitchShifterPopup().start();
  } catch (err) {
    console.error("Popup: erreur fatale.", err);
  }
});
//# sourceMappingURL=popup.js.map
